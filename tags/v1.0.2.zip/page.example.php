<?php
/*
	Template Name: Example Page Test
*/

setup_pagelines_template();
