<?php
/*
Template Name: Paid Content
*/



setup_pagelines_template();
