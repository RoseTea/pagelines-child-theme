<?php
/*
	Template Name: Quest Page
*/

setup_pagelines_template();
