<?php

/*

	Template Name: Stats Page

*/



setup_pagelines_template();

